import React, { useState, useEffect } from "react";
import styled from "styled-components";
import axios from "axios";

function App() {
  const [page, setPage] = useState("do");
  const [inputV, setInput] = useState("");
  const [boxes, setBoxes] = useState([]);

  useEffect(() => {
    GetApi();
  }, []); // 컴포넌트가 처음 렌더링될 때만 실행

  const GetApi = () => {
    // 초기 데이터 가져오기
    axios
      .get("http://localhost:3000/todos")
      .then((response) => {
        console.log(response.data);
        setBoxes(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  const RemoveTodo = (id) => {
    //삭제
    console.log("id", id);
    axios
      .delete("http://localhost:3000/todos/" + id)
      .then((response) => {
        console.log("Todo delete successfully", response.data);
        // 추가된 투두를 화면에 반영하기 위해 다시 데이터를 가져옴
        axios
          .get("http://localhost:3000/todos")
          .then((response) => {
            setBoxes(response.data);
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
      })
      .catch((error) => {
        console.error("Error adding todo:", error);
      });
  };

  const handleRouter = (e) => {
    setPage(e);
  };

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleAdderClick = () => {
    // 새로운 투두 추가
    axios
      .post("http://localhost:3000/todos", { todo: inputV })
      .then((response) => {
        console.log("Todo added successfully", response.data);
        // 추가된 투두를 화면에 반영하기 위해 다시 데이터를 가져옴
        axios
          .get("http://localhost:3000/todos")
          .then((response) => {
            setBoxes(response.data);
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
      })
      .catch((error) => {
        console.error("Error adding todo:", error);
      });
  };
  const handleBoxClick = (id) => {
    setBoxes(
      boxes.map((box) => (box.id === id ? { ...box, color: !box.color } : box))
    );
    axios
      .put("http://localhost:3000/todos/" + id + "/complete")
      .then((response) => {
        console.log("성공", response.date);
        axios
          .get("http://localhost:3000/todos")
          .then((response) => {
            setBoxes(response.data);
          })
          .catch((error) => {
            console.error("Error fetching data:", error);
          });
      })
      .catch((e) => {
        console.error("삭제 이상 깔깔깔" + e);
      });
  };

  return (
    <>
      <Header>
        <div onClick={() => handleRouter("do")}>추가</div>
        <div onClick={() => handleRouter("se")}>보기</div>
        <div onClick={() => handleRouter("re")}>삭제</div>
        <div onClick={() => handleRouter("dn")}>끝</div>
      </Header>
      {page === "do" ? (
        <AddDo>
          <div style={{ display: "flex" }}>
            <input
              type="text"
              maxLength={10}
              value={inputV}
              onChange={handleInputChange}
            />
            <button onClick={handleAdderClick}>CHUUGA</button>
          </div>
        </AddDo>
      ) : page === "se" ? (
        <SeeDo>
          {boxes.map((box) => (
            <div key={box.id} style={{ display: "flex" }}>
              <SeeBox onClick={() => handleBoxClick(box.id)} SC={box.completed}>
                {box.task}
              </SeeBox>
              <button
                style={{ backgroundColor: "red", color: "black" }}
                onClick={() => {
                  RemoveTodo(box.id);
                }}
              >
                삭제
              </button>
            </div>
          ))}
        </SeeDo>
      ) : page === "re" ? (
        <DoneDo>완료</DoneDo>
      ) : (
        <RevDo>리무브</RevDo>
      )}
    </>
  );
}

const Header = styled.div`
  width: 100%;
  height: 50px;
  background-color: yellow;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 100px;
`;

const AddDo = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: start;
  align-items: center;
`;

const SeeDo = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: start;
  align-items: center;
`;

const DoneDo = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: start;
  align-items: center;
`;

const RevDo = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: start;
  align-items: center;
`;

const SeeBox = styled.div`
  width: 100px;
  height: 50px;
  border: 1px solid black;
  background-color: ${(props) =>
    props.SC ? "gray" : "white"}; // 동적으로 배경색 변경
`;

export default App;
