import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [timeTable, setTimeTable] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        "http://127.0.0.1:5000/api/professor/time-table/1"
      );
      console.log("콘솔", response.data.lectures);
      setTimeTable(response.data.lectures || []); // response.data.lectures가 없을 경우 빈 배열로 초기화
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const renderTimeTable = () => {
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    const periods = [
      "09시",
      "10시",
      "11시",
      "12시",
      "13시",
      "14시",
      "15시",
      "16시",
      "17시",
      "18시",
    ];

    return (
      <table className="time-table">
        <thead>
          <tr>
            <th>시간/요일</th>
            {days.map((day) => (
              <th key={day}>{day}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {periods.map((period) => (
            <tr key={period}>
              <td>{period}</td>
              {days.map((day) => {
                const lecturesForPeriod = timeTable.filter((lecture) => {
                  const lectureStartTime = parseInt(
                    lecture.lecture_time.slice(0, 2)
                  );
                  const lectureEndTime = parseInt(
                    lecture.lecture_end.slice(0, 2)
                  );
                  const targetPeriod = parseInt(period.slice(0, 2));
                  return (
                    lecture.day === day &&
                    targetPeriod >= lectureStartTime &&
                    targetPeriod <= lectureStartTime + lecture.credit - 1
                  );
                });
                return (
                  <td key={`${day}-${period}`}>
                    {lecturesForPeriod.map((lecture, index) => (
                      <div key={index}>
                        <div>{lecture.course_name}</div>
                        <div>Credit: {lecture.credit}</div>
                        <div>
                          {lecture.lecture_time} - {lecture.lecture_end}
                        </div>
                      </div>
                    ))}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div className="App">
      <h1>시간표</h1>
      {renderTimeTable()}
    </div>
  );
}

export default App;
